import { Image } from "expo-image";
import { Stack, useLocalSearchParams, useRouter } from "expo-router";
import * as Haptics from "expo-haptics";
import {
  Bookmark,
  ChevronLeft,
  Clock,
  Eye,
  Heart,
  MapPin,
  MessageCircle,
  Navigation,
  Send,
  Share2,
} from "lucide-react-native";
import React, { useCallback, useEffect, useState } from "react";
import {
  KeyboardAvoidingView,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";

import { ImageCarousel } from "@/components/ImageCarousel";
import { MapPlaceholder } from "@/components/MapPlaceholder";
import Colors from "@/constants/colors";
import { CATEGORY_MAP } from "@/constants/categories";
import { useTick } from "@/hooks/useTick";
import { useDiscount, useDiscounts } from "@/providers/DiscountsProvider";
import { api } from "@/services/api";
import type { Comment } from "@/types/discount";
import {
  formatTimeSince,
  formatDistance,
  formatFullDate,
  formatTimeAgo,
  formatViews,
} from "@/utils/time";

function impact(style: Haptics.ImpactFeedbackStyle = Haptics.ImpactFeedbackStyle.Light) {
  if (Platform.OS !== "web") Haptics.impactAsync(style).catch(() => {});
}

export default function DiscountDetailScreen() {
  useTick(1000);
  const router = useRouter();
  const { id } = useLocalSearchParams<{ id: string }>();
  const discount = useDiscount(id ?? "");
  const { toggleLike, toggleSave, toggleGoing, incrementViews } = useDiscounts();
  const [comment, setComment] = useState<string>("");
  const [comments, setComments] = useState<Comment[]>([]);

  useEffect(() => {
    if (id) {
      incrementViews(id);
      api.getComments(id).then((res) => {
        if (res.success && res.data) setComments(res.data);
      });
    }
  }, [id, incrementViews]);

  const onSendComment = useCallback(async () => {
    const txt = comment.trim();
    if (!txt || !id) return;
    const res = await api.addComment(id, txt);
    if (res.success && res.data) {
      setComments((cs) => [res.data!, ...cs]);
    }
    setComment("");
    impact();
  }, [comment, id]);

  if (!discount) {
    return (
      <View style={[styles.root, { alignItems: "center", justifyContent: "center" }]}>
        <Stack.Screen options={{ title: "Скидка" }} />
        <Text style={{ color: Colors.textMuted }}>Скидка не найдена</Text>
      </View>
    );
  }

  const cat = CATEGORY_MAP[discount.category];
  const Icon = cat.icon;
  const elapsed = formatTimeSince(discount.postedAt);

  return (
    <View style={styles.root}>
      <Stack.Screen options={{ headerShown: false }} />

      <KeyboardAvoidingView
        behavior={Platform.OS === "ios" ? "padding" : undefined}
        style={{ flex: 1 }}
      >
        <ScrollView
          showsVerticalScrollIndicator={false}
          contentContainerStyle={{ paddingBottom: 120 }}
        >
          {/* ── Hero carousel ── */}
          <View style={styles.heroWrap}>
            <ImageCarousel images={discount.images} height={300}>
              {/* Header overlay */}
              <SafeAreaView edges={["top"]} style={styles.heroHeader} pointerEvents="box-none">
                <View style={styles.heroHeaderRow}>
                  <Pressable
                    onPress={() => router.back()}
                    style={styles.headerBtn}
                    hitSlop={12}
                  >
                    <ChevronLeft size={22} color={Colors.text} strokeWidth={2} />
                  </Pressable>
                  <View style={styles.heroActions}>
                    <Pressable
                      onPress={() => {
                        toggleSave(discount.id);
                      }}
                      style={styles.headerBtn}
                      hitSlop={12}
                    >
                      <Bookmark
                        size={20}
                        color={discount.saved ? Colors.primary : Colors.text}
                        strokeWidth={2}
                        fill={discount.saved ? Colors.primary : "transparent"}
                      />
                    </Pressable>
                    <Pressable style={styles.headerBtn} hitSlop={12}>
                      <Share2 size={20} color={Colors.text} strokeWidth={2} />
                    </Pressable>
                  </View>
                </View>
              </SafeAreaView>

              {/* Bottom overlay badges */}
              <View style={styles.heroBottom} pointerEvents="box-none">
                <View style={styles.discountBadge}>
                  <Text style={styles.discountNumber}>−{discount.percent}%</Text>
                </View>
                <View style={styles.timerBadge} pointerEvents="box-none">
                  <Clock size={12} color={Colors.text} strokeWidth={2} />
                  <Text style={styles.timerText}>
                    {elapsed}
                  </Text>
                </View>
              </View>
            </ImageCarousel>
          </View>

          {/* ── Content ── */}
          <View style={styles.content}>

            {/* Title */}
            <Text style={styles.title}>{discount.title}</Text>

            {/* Author row */}
            <View style={styles.authorRow}>
              <Image
                source={{ uri: discount.author.avatar }}
                style={styles.authorAvatar}
                contentFit="cover"
              />
              <View style={styles.authorBody}>
                <View style={styles.authorLine}>
                  <Text style={styles.authorName}>{discount.author.name}</Text>
                  {discount.author.verified && (
                    <View style={styles.verifiedDot} />
                  )}
                </View>
                <Text style={styles.authorTime}>
                  {formatFullDate(discount.postedAt)}
                </Text>
              </View>
            </View>

            {/* Category & Location */}
            <View style={styles.metaRow}>
              <View style={[styles.chip, { backgroundColor: cat.color + "20" }]}>
                <Icon size={12} color={cat.color} strokeWidth={2} />
                <Text style={[styles.chipText, { color: cat.color }]}>
                  {cat.label}
                </Text>
              </View>
              <View style={styles.locationChip}>
                <MapPin size={12} color={Colors.textMuted} strokeWidth={2} />
                <Text style={styles.locationText} numberOfLines={1}>
                  {discount.locationName}
                </Text>
                <Text style={styles.locationDot}>·</Text>
                <Text style={styles.distanceText}>
                  {formatDistance(discount.distanceKm)}
                </Text>
              </View>
            </View>

            {/* Prices */}
            {discount.discountedPrice !== undefined && (
              <View style={styles.priceRow}>
                <Text style={styles.priceNow}>
                  {discount.discountedPrice.toLocaleString("ru-RU")} ₽
                </Text>
                {discount.originalPrice !== undefined && (
                  <>
                    <Text style={styles.priceDash}>—</Text>
                    <Text style={styles.priceWas}>
                      {discount.originalPrice.toLocaleString("ru-RU")} ₽
                    </Text>
                    <View style={styles.savingsPill}>
                      <Text style={styles.savingsText}>
                        Экономия{" "}
                        {(
                          discount.originalPrice - discount.discountedPrice
                        ).toLocaleString("ru-RU")}{" "}
                        ₽
                      </Text>
                    </View>
                  </>
                )}
              </View>
            )}

            {/* Stats row */}
            <View style={styles.statsRow}>
              <View style={styles.statItem}>
                <Eye size={14} color={Colors.textMuted} strokeWidth={2} />
                <Text style={styles.statText}>
                  {formatViews(discount.views)}
                </Text>
              </View>
              <Text style={styles.statSeparator}>·</Text>
              <View style={styles.statItem}>
                <Heart size={14} color={Colors.textMuted} strokeWidth={2} />
                <Text style={styles.statText}>{discount.likes}</Text>
              </View>
              <Text style={styles.statSeparator}>·</Text>
              <View style={styles.statItem}>
                <MessageCircle
                  size={14}
                  color={Colors.textMuted}
                  strokeWidth={2}
                />
                <Text style={styles.statText}>{discount.comments}</Text>
              </View>
            </View>

            {/* CTA — "Я иду" */}
            <Pressable
              onPress={() => {
                impact(Haptics.ImpactFeedbackStyle.Medium);
                toggleGoing(discount.id);
              }}
              style={[
                styles.cta,
                discount.isGoing && { backgroundColor: Colors.successLight },
              ]}
            >
              <Text
                style={[
                  styles.ctaText,
                  discount.isGoing && { color: Colors.success },
                ]}
              >
                {discount.isGoing
                  ? `Идёшь · ${discount.going} человек`
                  : "Я иду"}
              </Text>
            </Pressable>

            {/* Action row: Like / Comment / Share */}
            <View style={styles.actionRow}>
              <Pressable
                onPress={() => {
                  impact();
                  toggleLike(discount.id);
                }}
                style={styles.actionBtn}
                hitSlop={8}
              >
                <Heart
                  size={22}
                  color={discount.liked ? Colors.danger : Colors.textMuted}
                  strokeWidth={2}
                  fill={discount.liked ? Colors.danger : "transparent"}
                />
                <Text
                  style={[
                    styles.actionLabel,
                    discount.liked && { color: Colors.danger },
                  ]}
                >
                  {discount.likes}
                </Text>
              </Pressable>
              <Pressable style={styles.actionBtn} hitSlop={8}>
                <MessageCircle size={22} color={Colors.textMuted} strokeWidth={2} />
                <Text style={styles.actionLabel}>{discount.comments}</Text>
              </Pressable>
              <Pressable style={styles.actionBtn} hitSlop={8}>
                <Share2 size={22} color={Colors.textMuted} strokeWidth={2} />
              </Pressable>
            </View>

            {/* ── Map ── */}
            <View style={styles.section}>
              <Text style={styles.sectionTitle}>Где найти</Text>
              <View style={styles.mapBox}>
                <MapPlaceholder
                  discounts={[discount]}
                  selectedId={discount.id}
                />
              </View>
              <Pressable style={styles.directionsBtn}>
                <Navigation size={16} color={Colors.primary} strokeWidth={2} />
                <Text style={styles.directionsText}>Построить маршрут</Text>
              </Pressable>
            </View>

            {/* ── Comments ── */}
            <View style={styles.section}>
              <View style={styles.sectionHeader}>
                <Text style={styles.sectionTitle}>
                  Комментарии · {comments.length}
                </Text>
              </View>
              {comments.map((c) => (
                <View key={c.id} style={styles.commentRow}>
                  <Image
                    source={{ uri: c.author.avatar }}
                    style={styles.commentAv}
                    contentFit="cover"
                  />
                  <View style={styles.commentBody}>
                    <View style={styles.commentHead}>
                      <Text style={styles.commentName}>{c.author.name}</Text>
                      <Text style={styles.commentTime}>
                        {formatTimeAgo(c.postedAt)}
                      </Text>
                    </View>
                    <Text style={styles.commentText}>{c.text}</Text>
                  </View>
                </View>
              ))}
            </View>
          </View>
        </ScrollView>

        {/* Comment input bar */}
        <SafeAreaView edges={["bottom"]} style={styles.inputBar}>
          <View style={styles.inputBarInner}>
            <TextInput
              value={comment}
              onChangeText={setComment}
              placeholder="Написать комментарий"
              placeholderTextColor={Colors.textMuted}
              style={styles.commentInput}
            />
            <Pressable
              onPress={onSendComment}
              disabled={!comment.trim()}
              style={[
                styles.sendBtn,
                !comment.trim() && { opacity: 0.4 },
              ]}
            >
              <Send size={18} color={Colors.primary} strokeWidth={2} />
            </Pressable>
          </View>
        </SafeAreaView>
      </KeyboardAvoidingView>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: Colors.background },

  // ── Hero image ──
  heroWrap: {
    width: "100%",
    height: 300,
    backgroundColor: Colors.cardSecondary,
    position: "relative",
  },
  // ── Header ──
  heroHeader: {
    position: "absolute",
    top: 0,
    left: 0,
    right: 0,
  },
  heroHeaderRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    paddingHorizontal: 16,
    paddingTop: 6,
  },
  heroActions: { flexDirection: "row", gap: 4 },
  headerBtn: {
    width: 40,
    height: 40,
    alignItems: "center",
    justifyContent: "center",
  },

  // ── Badges on hero ──
  heroBottom: {
    position: "absolute",
    left: 16,
    right: 16,
    bottom: 14,
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },
  discountBadge: {
    backgroundColor: Colors.primary,
    paddingHorizontal: 14,
    paddingVertical: 8,
    borderRadius: 8,
  },
  discountNumber: {
    color: Colors.text,
    fontSize: 22,
    fontWeight: "700" as const,
    letterSpacing: -0.7,
  },
  timerBadge: {
    flexDirection: "row",
    alignItems: "center",
    gap: 5,
  },
  timerText: {
    fontSize: 13,
    fontVariant: ["tabular-nums"] as const,
    letterSpacing: 0.1,
    color: Colors.text,
    textShadowColor: "rgba(0,0,0,0.65)",
    textShadowOffset: { width: 0, height: 1 },
    textShadowRadius: 3,
  },

  // ── Content ──
  content: { paddingHorizontal: 20, paddingTop: 20 },

  // Title
  title: {
    fontSize: 24,
    fontWeight: "700" as const,
    color: Colors.text,
    lineHeight: 30,
    letterSpacing: -0.5,
    marginBottom: 16,
  },

  // Author
  authorRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
    marginBottom: 14,
  },
  authorAvatar: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: Colors.cardSecondary,
  },
  authorBody: { flex: 1, gap: 1 },
  authorLine: {
    flexDirection: "row",
    alignItems: "center",
    gap: 6,
  },
  authorName: {
    fontSize: 15,
    color: Colors.text,
    letterSpacing: -0.2,
  },
  verifiedDot: {
    width: 6,
    height: 6,
    borderRadius: 3,
    backgroundColor: Colors.primary,
  },
  authorTime: {
    fontSize: 13,
    color: Colors.textMuted,
    letterSpacing: -0.1,
  },

  // Category & Location
  metaRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: 12,
    marginBottom: 16,
    flexWrap: "wrap" as const,
  },
  chip: {
    flexDirection: "row",
    alignItems: "center",
    gap: 5,
    paddingHorizontal: 10,
    paddingVertical: 5,
    borderRadius: 8,
  },
  chipText: { fontSize: 12, letterSpacing: 0.2 },
  locationChip: {
    flexDirection: "row",
    alignItems: "center",
    gap: 4,
    flexShrink: 1,
  },
  locationText: {
    fontSize: 13,
    color: Colors.textMuted,
    flexShrink: 1,
  },
  locationDot: { color: Colors.textMuted, fontSize: 12 },
  distanceText: { fontSize: 13, color: Colors.textMuted },

  // Prices
  priceRow: {
    flexDirection: "row",
    alignItems: "baseline",
    gap: 8,
    marginBottom: 16,
    flexWrap: "wrap" as const,
  },
  priceNow: {
    fontSize: 28,
    fontWeight: "700" as const,
    color: Colors.primary,
    letterSpacing: -0.7,
  },
  priceDash: {
    fontSize: 18,
    color: Colors.textMuted,
    marginHorizontal: 2,
  },
  priceWas: {
    fontSize: 18,
    color: Colors.textMuted,
    textDecorationLine: "line-through" as const,
  },
  savingsPill: {
    backgroundColor: Colors.accentLight,
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 6,
  },
  savingsText: {
    fontSize: 13,
    color: Colors.accent,
    letterSpacing: -0.1,
  },

  // Stats
  statsRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
    marginBottom: 20,
  },
  statItem: {
    flexDirection: "row",
    alignItems: "center",
    gap: 4,
  },
  statText: {
    fontSize: 14,
    color: Colors.textMuted,
    fontVariant: ["tabular-nums"] as const,
  },
  statSeparator: {
    color: Colors.textMuted,
    fontSize: 14,
  },

  // CTA
  cta: {
    height: 52,
    borderRadius: 14,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: Colors.primary,
    marginBottom: 16,
  },
  ctaText: {
    color: Colors.text,
    fontSize: 17,
    fontWeight: "600" as const,
    letterSpacing: -0.3,
  },

  // Actions
  actionRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: 32,
    marginBottom: 28,
    paddingVertical: 4,
  },
  actionBtn: {
    flexDirection: "row",
    alignItems: "center",
    gap: 6,
  },
  actionLabel: {
    fontSize: 14,
    color: Colors.textMuted,
    fontVariant: ["tabular-nums"] as const,
  },

  // ── Section (Map / Comments) ──
  section: { marginTop: 0, gap: 12 },
  sectionHeader: { marginBottom: 4 },
  sectionTitle: {
    fontSize: 11,
    color: Colors.textMuted,
    letterSpacing: 0.5,
    textTransform: "uppercase" as const,
  },
  mapBox: {
    height: 180,
    borderRadius: 16,
    overflow: "hidden" as const,
  },
  directionsBtn: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 8,
    height: 46,
    borderRadius: 12,
    backgroundColor: Colors.card,
  },
  directionsText: {
    color: Colors.text,
    fontSize: 14,
    letterSpacing: -0.2,
  },

  // ── Comments ──
  commentRow: {
    flexDirection: "row",
    gap: 10,
    paddingVertical: 12,
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: Colors.border,
  },
  commentAv: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: Colors.cardSecondary,
  },
  commentBody: { flex: 1, gap: 3 },
  commentHead: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },
  commentName: {
    fontSize: 13,
    color: Colors.text,
    letterSpacing: -0.2,
  },
  commentTime: { fontSize: 11, color: Colors.textMuted },
  commentText: {
    fontSize: 14,
    color: Colors.textSecondary,
    lineHeight: 19,
  },

  // ── Comment input bar ──
  inputBar: {
    position: "absolute",
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: Colors.background,
    paddingHorizontal: 16,
    paddingVertical: 10,
    borderTopWidth: StyleSheet.hairlineWidth,
    borderTopColor: Colors.border,
  },
  inputBarInner: {
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
    backgroundColor: Colors.card,
    borderRadius: 14,
    paddingHorizontal: 14,
  },
  commentInput: {
    flex: 1,
    fontSize: 14,
    color: Colors.text,
    paddingVertical: 12,
    letterSpacing: -0.2,
  },
  sendBtn: { padding: 8 },
});
