export const ENV = {
  API_URL: "http://82.202.130.145/api",
  S3_BUCKET: "skidki-media",
  APP_VERSION: "1.0.0",
} as const;
